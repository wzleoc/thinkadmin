-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : project
-- 
-- Part : #1
-- Date : 2018-04-19 20:57:44
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `admin`
-- -----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `status` tinyint(4) DEFAULT '1',
  `role_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------
-- Records of `admin`
-- -----------------------------
INSERT INTO `admin` VALUES ('1', 'adminn', '2169046620@qq.com', 'beb2ca9bca2c1d1610b55657e7383ae8', 'SayY2ZwtjjRJZi3v6hm7NGqO67Vv54EI9XCpIXARl4fw4KnuW6zNKHUX2Kwt', '1521600653', '1524032257', 'http://fix.com/uploads/images/20180418\\f5837ba65a759bc206c3130b7666d29b.jpg', '1', '1');
INSERT INTO `admin` VALUES ('50', 'weiwei2', '216488@qq.com', 'beb2ca9bca2c1d1610b55657e7383ae8', '', '1524041914', '1524128030', 'http://fix.com/uploads/images/20180418\\d6fb846194cadbcb8795310817005a9c.jpg', '1', '15');
INSERT INTO `admin` VALUES ('49', 'weiwei1', '2164848148@qq.com', 'beb2ca9bca2c1d1610b55657e7383ae8', '', '1524041914', '1524128921', 'http://fix.com/uploads/images/20180418\\d6fb846194cadbcb8795310817005a9c.jpg', '1', '15');
INSERT INTO `admin` VALUES ('48', 'wggwgegw', '216484814548@qq.com', 'beb2ca9bca2c1d1610b55657e7383ae8', '', '1524041914', '1524141403', 'http://fix.com/uploads/images/20180418\\d6fb846194cadbcb8795310817005a9c.jpg', '1', '15');
INSERT INTO `admin` VALUES ('51', 'weiweiooo', '21648481348@qq.com', 'beb2ca9bca2c1d1610b55657e7383ae8', '', '1524041914', '1524141386', 'http://fix.com/uploads/images/20180418\\d6fb846194cadbcb8795310817005a9c.jpg', '1', '15');
INSERT INTO `admin` VALUES ('53', 'weiwheheheh', '2164882@qq.com', 'beb2ca9bca2c1d1610b55657e7383ae8', '', '1524041914', '1524141097', 'http://fix.com/uploads/images/20180418\\d6fb846194cadbcb8795310817005a9c.jpg', '1', '15');
INSERT INTO `admin` VALUES ('54', 'weiwei1', '21648348148@qq.com', 'beb2ca9bca2c1d1610b55657e7383ae8', '', '1524041914', '1524041914', 'http://fix.com/uploads/images/20180418\\d6fb846194cadbcb8795310817005a9c.jpg', '1', '15');
INSERT INTO `admin` VALUES ('55', 'weiwei', '2164848414548@qq.com', 'beb2ca9bca2c1d1610b55657e7383ae8', '', '1524041914', '1524041914', 'http://fix.com/uploads/images/20180418\\d6fb846194cadbcb8795310817005a9c.jpg', '1', '15');
INSERT INTO `admin` VALUES ('56', 'weiwei1', '216485481348@qq.com', 'beb2ca9bca2c1d1610b55657e7383ae8', '', '1524041914', '1524041914', 'http://fix.com/uploads/images/20180418\\d6fb846194cadbcb8795310817005a9c.jpg', '1', '15');
INSERT INTO `admin` VALUES ('69', 'weiwei888', '252353@qq.com', 'beb2ca9bca2c1d1610b55657e7383ae8', '', '1524114036', '1524114036', 'http://fix.com/uploads/images/20180419\\5930072a103432d50b97fb31a02810ab.jpg', '1', '15');
INSERT INTO `admin` VALUES ('67', 'admin123', '787878@qq.com', 'beb2ca9bca2c1d1610b55657e7383ae8', '', '1524053355', '1524053355', 'http://fix.com/uploads/images/20180418\\1b0e92851b7b1298da606496f027b58a.jpg', '1', '15');
INSERT INTO `admin` VALUES ('70', '测试添加gerg', '545435345@qq.com', 'beb2ca9bca2c1d1610b55657e7383ae8', '', '1524130732', '1524130732', 'http://fix.com/uploads/images/20180419\\3e50c713d28834f4fcd243c25783312e.jpg', '1', '15');
INSERT INTO `admin` VALUES ('71', 'gwggggg', '4124144@qq.com', 'beb2ca9bca2c1d1610b55657e7383ae8', '', '1524141190', '1524141190', 'http://fix.com/uploads/images/20180419\\cdacca10058a17db0093819815004b7c.png', '1', '1');
INSERT INTO `admin` VALUES ('68', 'admin888', '21690466209087@qq.com', 'beb2ca9bca2c1d1610b55657e7383ae8', '', '1524054725', '1524054725', 'http://fix.com/uploads/images/20180418\\bee9b37ed75f960b599a2c362c73f20f.jpg', '1', '1');

-- -----------------------------
-- Table structure for `config`
-- -----------------------------
DROP TABLE IF EXISTS `config`;
CREATE TABLE `config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `value` text COMMENT '配置值',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `config`
-- -----------------------------
INSERT INTO `config` VALUES ('1', 'web_site_title', '微品匠心后台管理系统1');
INSERT INTO `config` VALUES ('2', 'web_site_description', '微品匠心后台管理系统');
INSERT INTO `config` VALUES ('3', 'web_site_keyword', '微信开发，公众号开发，移动端开发，h5');
INSERT INTO `config` VALUES ('4', 'web_site_icp', '川ICP备15095485号-1');
INSERT INTO `config` VALUES ('5', 'web_site_cnzz', '');
INSERT INTO `config` VALUES ('6', 'web_site_copy', 'Copyright © 2018 微品匠心后台管理系统 All rights reserved.');
INSERT INTO `config` VALUES ('7', 'web_site_close', '1');
INSERT INTO `config` VALUES ('8', 'list_rows', '5');
INSERT INTO `config` VALUES ('9', 'admin_allow_ip', '');
INSERT INTO `config` VALUES ('10', 'alisms_appkey', 'LTAIxg8jIj24ATdH');
INSERT INTO `config` VALUES ('11', 'alisms_appsecret', 'JWzTihrdS1AlyqWwWDYZIuKqGl9rkJ');
INSERT INTO `config` VALUES ('12', 'alisms_signname', 'angular后台');
INSERT INTO `config` VALUES ('13', 'qiniu_appkey', '');
INSERT INTO `config` VALUES ('14', 'qiniu_secret', '');
INSERT INTO `config` VALUES ('15', 'qiniu_bucket', '');
INSERT INTO `config` VALUES ('16', 'qiniu_domain', '');

-- -----------------------------
-- Table structure for `node`
-- -----------------------------
DROP TABLE IF EXISTS `node`;
CREATE TABLE `node` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(80) NOT NULL DEFAULT '',
  `title` char(20) NOT NULL DEFAULT '',
  `type` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `css` varchar(20) NOT NULL COMMENT '样式',
  `condition` char(100) NOT NULL DEFAULT '',
  `pid` int(11) NOT NULL DEFAULT '0' COMMENT '父栏目ID',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '添加时间',
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `node`
-- -----------------------------
INSERT INTO `node` VALUES ('1', '#', '系统管理', '1', '1', 'fa fa-gear', '', '0', '3', '1446535750', '1477312169');
INSERT INTO `node` VALUES ('2', 'admin/admin/index', '用户管理', '1', '1', '', '', '1', '10', '1446535750', '1477312169');
INSERT INTO `node` VALUES ('3', 'admin/role/index', '角色管理', '1', '1', '', '', '1', '20', '1446535750', '1477312169');
INSERT INTO `node` VALUES ('4', 'admin/menu/index', '菜单管理', '1', '1', '', '', '1', '30', '1446535750', '1477312169');
INSERT INTO `node` VALUES ('5', '#', '数据库管理', '1', '1', 'fa fa-database', '', '0', '10', '1446535750', '1477312169');
INSERT INTO `node` VALUES ('6', 'admin/data/index', '数据库备份', '1', '1', '', '', '5', '50', '1446535750', '1477312169');
INSERT INTO `node` VALUES ('7', 'admin/data/optimize', '优化表', '1', '1', '', '', '6', '50', '1477312169', '1477312169');
INSERT INTO `node` VALUES ('8', 'admin/data/repair', '修复表', '1', '1', '', '', '6', '50', '1477312169', '1477312169');
INSERT INTO `node` VALUES ('9', 'admin/admin/create', '添加用户', '1', '1', '', '', '2', '50', '1477312169', '1524141973');
INSERT INTO `node` VALUES ('10', 'admin/admin/edit', '编辑用户', '1', '1', '', '', '2', '50', '1477312169', '1477312169');
INSERT INTO `node` VALUES ('11', 'admin/admin/delete', '删除用户', '1', '1', '', '', '2', '50', '1477312169', '1477312169');
INSERT INTO `node` VALUES ('27', 'admin/data/import', '数据库还原', '1', '1', '', '', '5', '50', '1477639870', '1524109225');
INSERT INTO `node` VALUES ('28', 'admin/data/revert', '还原', '1', '1', '', '', '27', '50', '1477639972', '1477639972');
INSERT INTO `node` VALUES ('29', 'admin/data/del', '删除', '1', '1', '', '', '27', '50', '1477640011', '1477640011');
INSERT INTO `node` VALUES ('30', 'admin/role/create', '添加角色', '1', '1', '', '', '3', '50', '1477640011', '1521602116');
INSERT INTO `node` VALUES ('31', 'admin/role/edit', '编辑角色', '1', '1', '', '', '3', '50', '1477640011', '1521602131');
INSERT INTO `node` VALUES ('32', 'admin/role/delete', '删除角色', '1', '1', '', '', '3', '50', '1477640011', '1521602160');
INSERT INTO `node` VALUES ('34', 'admin/role/getaccessdata', '权限分配', '1', '1', '', '', '3', '50', '1477640011', '1524048743');
INSERT INTO `node` VALUES ('35', 'admin/menu/menustore', '添加菜单', '1', '1', '', '', '4', '50', '1477640011', '1524048758');
INSERT INTO `node` VALUES ('36', 'admin/menu/edit', '编辑菜单', '1', '1', '', '', '4', '50', '1477640011', '1521603823');
INSERT INTO `node` VALUES ('37', 'admin/menu/delete', '删除菜单', '1', '1', '', '', '4', '50', '1477640011', '1521603759');
INSERT INTO `node` VALUES ('38', 'admin/menu/status', '菜单状态', '1', '1', '', '', '4', '50', '1477640011', '1521603697');
INSERT INTO `node` VALUES ('39', 'admin/menu/order', '菜单排序', '1', '1', '', '', '4', '50', '1477640011', '1521602641');
INSERT INTO `node` VALUES ('61', 'admin/config/index', '配置管理', '1', '1', '', '', '1', '3', '1479908607', '1479908607');
INSERT INTO `node` VALUES ('63', 'admin/config/save', '保存配置', '1', '1', '', '', '61', '50', '1479908607', '1487943831');
INSERT INTO `node` VALUES ('83', '#', '示例', '1', '1', 'fa fa-paper-plane', '', '0', '50', '1505281878', '1505281878');
INSERT INTO `node` VALUES ('84', 'admin/demo/sms', '发送短信', '1', '1', '', '', '83', '50', '1505281944', '1524047900');
INSERT INTO `node` VALUES ('89', 'admin/admin/deletemany', '批量删除', '1', '1', '', '', '2', '50', '1521601628', '1524048726');
INSERT INTO `node` VALUES ('90', 'admin/admin/status', '状态修改', '1', '1', '', '', '2', '50', '1521601665', '1521601665');

-- -----------------------------
-- Table structure for `node_role`
-- -----------------------------
DROP TABLE IF EXISTS `node_role`;
CREATE TABLE `node_role` (
  `node_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------
-- Records of `node_role`
-- -----------------------------
INSERT INTO `node_role` VALUES ('9', '1');
INSERT INTO `node_role` VALUES ('83', '15');
INSERT INTO `node_role` VALUES ('4', '1');
INSERT INTO `node_role` VALUES ('3', '1');
INSERT INTO `node_role` VALUES ('2', '1');
INSERT INTO `node_role` VALUES ('1', '1');
INSERT INTO `node_role` VALUES ('37', '1');
INSERT INTO `node_role` VALUES ('34', '1');
INSERT INTO `node_role` VALUES ('10', '1');
INSERT INTO `node_role` VALUES ('11', '1');
INSERT INTO `node_role` VALUES ('31', '1');
INSERT INTO `node_role` VALUES ('32', '1');
INSERT INTO `node_role` VALUES ('39', '15');
INSERT INTO `node_role` VALUES ('35', '15');
INSERT INTO `node_role` VALUES ('38', '15');
INSERT INTO `node_role` VALUES ('37', '15');
INSERT INTO `node_role` VALUES ('36', '15');
INSERT INTO `node_role` VALUES ('4', '15');
INSERT INTO `node_role` VALUES ('30', '15');
INSERT INTO `node_role` VALUES ('31', '15');
INSERT INTO `node_role` VALUES ('32', '15');
INSERT INTO `node_role` VALUES ('34', '15');
INSERT INTO `node_role` VALUES ('3', '15');
INSERT INTO `node_role` VALUES ('90', '15');
INSERT INTO `node_role` VALUES ('10', '15');
INSERT INTO `node_role` VALUES ('9', '15');
INSERT INTO `node_role` VALUES ('89', '15');
INSERT INTO `node_role` VALUES ('2', '15');
INSERT INTO `node_role` VALUES ('63', '15');
INSERT INTO `node_role` VALUES ('61', '15');
INSERT INTO `node_role` VALUES ('1', '15');
INSERT INTO `node_role` VALUES ('84', '15');

-- -----------------------------
-- Table structure for `role`
-- -----------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------
-- Records of `role`
-- -----------------------------
INSERT INTO `role` VALUES ('1', '超级管理员', '1521600687', '1521600687');
INSERT INTO `role` VALUES ('15', '编辑', '1521600687', '1524141158');
INSERT INTO `role` VALUES ('32', '测试三', '1524106234', '1524109203');
